function openNav() {
  document.getElementById("aside").style.height = "270px";
  document.getElementById("list").style.display = "block";
} 

function closeNav() {
  document.getElementById("aside").style.height = "0";
  document.getElementById("list").style.display = "none";
}
  
function openNavv() {
 document.getElementById("league").style.height = "540px";
 document.getElementById("list2").style.display = "block";
}

function closeNavv() {
 document.getElementById("league").style.height = "0";
 document.getElementById("list2").style.display = "none";
}